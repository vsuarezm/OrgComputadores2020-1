from Parser import Parser
from Code import Code
from SymbolTable import SymbolTable
import sys

nombreArchivo = sys.argv[1]
parser1 = Parser(nombreArchivo)
symbolTable = SymbolTable()
code = Code()
romCounter=0
ramCounter=16
while(parser1.hasMoreCommands()):
    parser1.advance()
    parser1.lineaActual = parser1.deleteComment()
    if parser1.lineaActual == '':
        continue
    if parser1.commandType() == 'L_COMMAND':
        symbol = parser1.symbol()
        if not symbol in symbolTable.symbolTable:
            symbolTable.symbolTable[symbol]=romCounter
            romCounter+=1
    else:
        romCounter+=1

parser1.archivo.close()

nombreArchivosalida = nombreArchivo.split('.')[0]
outputFile = open(nombreArchivosalida+'.hack','w')
parser2 = Parser(nombreArchivo)
binario = ''

while(parser2.hasMoreCommands()):
    parser2.advance()
    parser2.lineaActual = parser2.deleteComment()
    if parser2.lineaActual == '':
        continue
    commandType=parser2.commandType()
    if commandType == 'A_COMMAND':
        symbol = parser2.symbol()
        if not symbol in symbolTable.symbolTable:
            symbolTable.symbolTable[symbol]=ramCounter
            ramCounter+=1
        address = symbolTable.symbolTable[symbol]
        addressBin = format(address,"016b")
        binario += addressBin+'\n'
    elif commandType == 'C_COMMAND':
        dest = parser2.dest()
        destBin = code.dest(dest)
        comp = parser2.comp()
        compBin = code.comp(comp)
        jmp = parser2.jmp()
        jmpBin = code.jmp(jmp)
        binario+='111'+compBin+destBin+jmpBin+'\n'

outputFile.write(binario)
outputFile.close()