import sys

class Parser:
	def __init__(self, archivo):
		try:
			self.lecturaArchivo=open(archivo)
			self.listaLineas=self.lecturaArchivo.readlines()
			self.lineaLeida=-1
			self.lineaActual=None
		except IOError as error:
			print("ERROR: abriendo el archivo")
			sys.exit(1)

	def hasMoreCommands(self):
		if self.lineaLeida < (len(self.listaLineas)-1):
			return True
		else:
			return False

	def advance(self):
		while self.hasMoreCommands() == True:
			self.lineaLeida=self.lineaLeida+1
			self.lineaActual=self.listaLineas[self.lineaLeida]

	def commandType(self):
		if "@" in self.lineaActual:
			return "A_COMMAND"
		elif "D" in self.lineaActual or "A" in self.lineaActual or "M" in self.lineaActual or "1" in self.lineaActual or "0" in self.lineaActual:
			return "C_COMMAND"
		elif "(" in self.lineaActual and ")" in self.lineaActual:
			return "L_COMMAND"
		else:
			print("ERROR: no es un comando válido")

	def symbol(self):
		if self.commandType() == "A_COMMAND":
			value = self.lineaActual[1:].strip()
			value.lower()
			if value[0].isdigit() and self.lineaActual[1:].islower():
					print("ERROR: porque empieza con un dígito y luego letras")
			elif " " in value:
				print("ERROR: porque el comando contiene espacios")
			elif "$" in value or "_" in value or "." in value or ":" in value or value.isdigit() or self.lineaActual[1:].islower():
				return value
		elif self.commandType() == "L_COMMAND":
			inicio=self.lineaActual[0]
			fin=self.lineaActual[len(self.lineaActual)-1]
			if inicio != "(":
				print("ERROR: en el comando")
			elif fin != ")":
				print("ERROR: en el comando")
			elif " " in self.lineaActual[1:]:
				print("ERROR: hay espacios en la variable")
			else:
				simbolo=self.lineaActual.strip()
				print("valor: " + str(simbolo))
				return simbolo			
		else:
			print("ERROR: no es un comando válido")


	def dest(self):
		if self.commandType() == "C_COMMAND":
			destDir = {'A':True,
            'D':True,
            'M':True,
            'MD':True,
            'AM':True,
            'AD':True,
            'AMD':True,
            'null':True}

			value = self.lineaActual[1:].strip()
			if "=" in self.lineaActual:
				position = value.index("=")
				dest = value[:position]
				try:
					if destDir[dest]==True:
						return dest
				except KeyError:	
					print("ERROR: no es un comando válido")
					exit(1)
			else:
				return "null"		


	def comp(self):
		if self.commandType() == "C_COMMAND":	
			compDira1 = {'M':True,
                 '!M':True,
                 '-M':True,
                 'M+1':True,
                 'M-1':True,
                 'D+M':True,
                 'D-M':True,
                 'M-D':True,
                 'D&M':True,
                 'D|M':True}
			compDira0 = {'0':True,
                 '1':True,
                 '-1':True,
                 'D':True,
                 'A':True,
                 '!D':True,
                 '!A':True,
                 '-D':True,
                 '-A':True,
                 'D+1':True,
                 'A+1':True,
                 'D-1':True,
                 'A-1':True,
                 'D+A':True,
                 'D-A':True,
                 'A-D':True,
                 'D&A':True,
                 'D|A':True}

			comp = " "
			aux = self.lineaActual.strip()
			if "=" in aux:
				if ";" in aux:
					positionEqual = aux.index("=")
					positionDot = aux.index(";")
					comp = aux[positionEqual+1:positionDot]
				else:
					positionEqual = aux.index("=")
					comp = aux[positionEqual+1:]
			elif ";" in aux:
					positionDot = aux.index(";")
					comp = aux[:positionDot]
			else: 
				comp = aux


			try:
				if "M" in comp:
					if compDira1[comp]==True:
						return comp
				else:
					if compDira0[comp]==True:
						return comp
			except KeyError:	
				print("ERROR: no es un comando válido")
				exit(1)
	

	def jmp(self):
		if self.commandType() == "C_COMMAND":
			compDirJMP = {'null':True,
                  		'JGT':True,
                  		'JEQ':True,
                  		'JGE':True,
                  		'JLT':True,
                  		'JNE':True,
                  		'JLE':True,
                  		'JMP':True}

			jmp = " "
			aux = self.lineaActual.strip()
			if ";" in aux:
				positionDot = aux.index(";")
				jmp = aux[positionDot+1:]
				try:
					if compDirJMP[jmp]==True:
						return jmp
				except KeyError:	
					print("ERROR: no es un comando válido")
					exit(1)
			else: 
				 return "null"


	def deleteComment(self):
		if '//' in self.comandoActual:
			self.lineaActual = self.lineaActual.split('//')[0].strip()
		return self.lineaActual